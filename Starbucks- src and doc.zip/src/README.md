yolo-octo-dangerzone
====================
flaberghasted Octopi!
