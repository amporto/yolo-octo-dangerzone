package main;

import javax.swing.JPanel;



/**
 * @author Proco
 * @version 1.0
 * @created 12-Oct-2014 7:46:07 PM
 */
public class TrendsGUI extends JPanel {

	public TrendsGUI(){

	}

	public void finalize() throws Throwable {

	}
}//end TrendsGUI