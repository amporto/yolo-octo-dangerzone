package main;

import javax.swing.JPanel;

/**
 * @author Brandon Bielefeld
 * 
 *         This class is the controller class for any interface elements on the
 *         ProfitsGUI tab.
 * 
 */
public class ProfitsGUI extends JPanel {

	public ProfitsGUI() {

	}

	public void finalize() throws Throwable {

	}
}// end ProfitsGUI