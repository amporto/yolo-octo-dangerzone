package main;


/**
 * @author Proco
 * @version 1.0
 * @created 12-Oct-2014 7:45:57 PM
 */
public class AI {

	private int timeInStock;
	private double timeOrderReady;
	private double timeSeating;
	public Middleware m_Middleware;

	public AI(){

	}

	public void finalize() throws Throwable {

	}
	public void seatRelease(){

	}

	public void seatTake(){

	}

	public void stockDecrease(){

	}

	public void stockIncrease(){

	}
}//end AI